import {lazy} from "react";
const HomePage = lazy(()=>import("@/pages/HomePage/index"))
const Login = lazy(()=>import("../components/Login/index"))
const Register = lazy(()=>import("../components/Register/index"))
const ContentPage = lazy(()=>import("../pages/ContentPage"))
// import Login from '../components/Login/index'
const routes = [
    {
        path:'/',
        component:Login
    },
    {
        path:'login',
        component:Login
    },
    {
        path:'/register',
        component:Register
    },
    {
        path:'/contentPage',
        component:ContentPage,
        children:[
            {
                path:'homePage',
                component:HomePage
            }
        ]
    },



]
export default  routes
