const Register =()=>{
    return (
        <div>
            <h4>我是注册组件</h4>
            <button onClick={()=>{window.location.href="#/login"}}>去登录</button>
        </div>
    )
}
export default Register
