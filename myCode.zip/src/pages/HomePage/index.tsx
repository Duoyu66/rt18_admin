const HomePage = ()=>{
    return (
        <div>
            <h4>我是首页</h4>
        </div>
    )
}
export default HomePage
