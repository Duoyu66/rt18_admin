import './index.css'
import React, {useEffect, useState} from 'react';
import {
    DesktopOutlined,
    FileOutlined,
    PieChartOutlined,
    TeamOutlined,
    UserOutlined,
    MenuUnfoldOutlined,
    MenuFoldOutlined
} from '@ant-design/icons';
import {Avatar, Button, MenuProps, Popover} from 'antd';
import {Breadcrumb, Layout, Menu, theme} from 'antd';
import {getHomePageMessage} from "../../api/HomePage";
import HeaderTop from "../../components/HeaderTop";
import myLogo from '@/assets/img/mylogo.png'
import {HashRouter as Router, Route, Routes} from "react-router-dom";
import routers from "@/router";

const {Header, Content, Footer, Sider} = Layout;

type MenuItem = Required<MenuProps>['items'][number];


function getItem(
    label: React.ReactNode,
    key: React.Key,

    icon?: React.ReactNode,
    path?:string,
    children?: MenuItem[],

): MenuItem {
    return {
        key,
        icon,
        path,
        children,
        label,

    } as MenuItem;
}

const items: MenuItem[] = [
    getItem('首页', '1', <PieChartOutlined/>,'/homePage'),
    getItem('工作台', '2', <DesktopOutlined/>),
    getItem('力扣分析', 'sub1', <UserOutlined/>, '/xxx',[
        getItem('分析台', '3'),
        getItem('Bill', '4'),
        getItem('Alex', '5'),
    ]),
    getItem('Team', 'sub2', <TeamOutlined/>, '/xxx',[getItem('Team 1', '6'), getItem('Team 2', '8')]),
    getItem('Files', '9', <FileOutlined/>,'/xxxx'),
];

const ContentPage = () => {
    let playod = {
        qq: '2523890936'
    }
    // useEffect(() => {
    //     getHomePageMessage(playod).then(res => {
    //         console.log(":res", res)
    //     })
    // }, [getHomePageMessage]);
    // const [collapsed, setCollapsed] = useState(false);
    const [collapsed, setCollapsed] = useState(false);
    const {
        token: {colorBgContainer, borderRadiusLG},
    } = theme.useToken();


    const toggleCollapsed = () => {
        setCollapsed(!collapsed);
    };
    return (
        <Layout style={{minHeight: '100vh'}}>
            <Sider theme="light"  style={{position:'relative'}} collapsed={collapsed} onCollapse={(value) => setCollapsed(value)}>
                {/*侧边栏logo*/}
                <div className="demo-logo-vertical">
                    <img src={myLogo} alt="图片错误"/>
                </div>
                {/*侧边栏主菜单*/}
                <Menu  expandIcon theme="light" defaultSelectedKeys={['1']} mode="inline" items={items}/>
                <Button type="text" className="flodOrExpand"  onClick={toggleCollapsed} style={{ marginBottom: 16 }}>
                    {collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                </Button>
            </Sider>
            <Layout>
                {/*layout布局顶部header*/}
                <HeaderTop></HeaderTop>


                <Content style={{margin: '0 16px'}}>
                    <Breadcrumb style={{margin: '16px 0'}}>
                        <Breadcrumb.Item>产品首页</Breadcrumb.Item>
                        <Breadcrumb.Item>百度产品列表</Breadcrumb.Item>
                        <Breadcrumb.Item>实例化产品页</Breadcrumb.Item>
                        <Breadcrumb.Item>用户资源</Breadcrumb.Item>
                    </Breadcrumb>
                    <div
                        style={{
                            padding: 24,
                            minHeight: 360,
                            background: colorBgContainer,
                            borderRadius: borderRadiusLG,
                        }}
                    >
                        {/*-------------*/}
                        {/*<Router>*/}
                        {/*    <Routes>*/}
                        {/*        {routers.map((items, index) => {*/}
                        {/*            return (*/}
                        {/*                <Route key={index} path={items.path} element={<items.component/>}></Route>*/}
                        {/*            )*/}
                        {/*        })}*/}
                        {/*    </Routes>*/}
                        {/*</Router> */}

                        {/*-------------*/}
                        Bill is a cat.

                    </div>
                </Content>
                <Footer style={{textAlign: 'center'}}>
                    My Bolg ©{new Date().getFullYear()} Created by LBL
                </Footer>
            </Layout>
        </Layout>
    )
}
export default ContentPage
