import {HashRouter as Router, Routes, Route} from "react-router-dom"
import {Suspense} from "react"
import routers from "../router"

const LayoutMain = () => {
    return (
        <Suspense fallback={<>loading...</>}>
            <Router>
                <Routes>
                    {routers.map((item, index) => {
                        return (
                            <Route key={index} path={item.path} element={<item.component/>}></Route>
                        )
                    })}
                </Routes>
            </Router>
        </Suspense>
    )
}
export default LayoutMain
