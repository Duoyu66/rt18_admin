import React from 'react';
import './App.css';
import LayoutMain from "./pages";

function App() {
    return (
        <div className="App">
            <LayoutMain></LayoutMain>
        </div>
    );
}

export default App;
